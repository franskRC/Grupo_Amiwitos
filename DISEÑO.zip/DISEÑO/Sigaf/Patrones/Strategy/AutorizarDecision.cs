﻿using Sigaf.Models;

namespace Sigaf.Patrones.Strategy
{
    public class AutorizarDecision : IDecisionEvaluacion
    {
        public string TipoOperacion => "Autorización";
        public string Descripcion => "Solicitud autorizada";
        public string MensajeExito => "Solicitud autorizada.";

        // RN-02: no se autoriza una solicitud incompleta
        public string? Validar(Solicitud s, string? motivo)
        {
            if (s.CodProducto == 0
                || s.CantidadSolicitada <= 0
                || string.IsNullOrWhiteSpace(s.Justificacion)
                || string.IsNullOrWhiteSpace(s.CodProductoNavigation?.UnidadMedida))
                return "No se puede autorizar una solicitud incompleta.";
            return null;
        }

        public void Aplicar(Solicitud s, string? motivo)
        {
            s.Estado = "Autorizada";
            s.MotivoEvaluacion = string.IsNullOrWhiteSpace(motivo) ? null : motivo;
        }
    }
}