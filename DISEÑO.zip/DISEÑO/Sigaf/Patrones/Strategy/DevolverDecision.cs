﻿using Sigaf.Models;

namespace Sigaf.Patrones.Strategy
{
    public class DevolverDecision : IDecisionEvaluacion
    {
        public string TipoOperacion => "Devolución";
        public string Descripcion => "Solicitud devuelta para corrección";
        public string MensajeExito => "Solicitud devuelta para corrección.";

        // RN-09: las observaciones son obligatorias
        public string? Validar(Solicitud s, string? motivo) =>
            string.IsNullOrWhiteSpace(motivo)
                ? "Debe indicar el motivo para devolver la solicitud."
                : null;

        public void Aplicar(Solicitud s, string? motivo)
        {
            s.Estado = "Devuelta para corrección";
            s.MotivoEvaluacion = motivo;
        }
    }
}