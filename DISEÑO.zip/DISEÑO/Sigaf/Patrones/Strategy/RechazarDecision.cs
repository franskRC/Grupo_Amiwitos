﻿using Sigaf.Models;

namespace Sigaf.Patrones.Strategy
{
    public class RechazarDecision : IDecisionEvaluacion
    {
        public string TipoOperacion => "Rechazo";
        public string Descripcion => "Solicitud rechazada";
        public string MensajeExito => "Solicitud rechazada.";

        // RN-08: el motivo es obligatorio
        public string? Validar(Solicitud s, string? motivo) =>
            string.IsNullOrWhiteSpace(motivo)
                ? "Debe indicar el motivo para rechazar la solicitud."
                : null;

        public void Aplicar(Solicitud s, string? motivo)
        {
            s.Estado = "Rechazada";
            s.MotivoEvaluacion = motivo;
        }
    }
}