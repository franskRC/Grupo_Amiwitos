﻿using Sigaf.Models;

namespace Sigaf.Patrones.Strategy
{
    public interface IDecisionEvaluacion
    {
        string TipoOperacion { get; }
        string Descripcion { get; }
        string MensajeExito { get; }

        // Devuelve el mensaje de error, o null si la decisión es válida
        string? Validar(Solicitud s, string? motivo);

        // Cambia el estado y el motivo de la solicitud
        void Aplicar(Solicitud s, string? motivo);
    }
}