﻿using Sigaf.Models;

namespace Sigaf.Patrones.Factory
{
    // PATRÓN FACTORY METHOD: el creador abstracto declara el método fábrica
    public abstract class HistorialCreator
    {
        public abstract Historial CrearRegistro(int codUsuario, string tipoOperacion,
            int codElemento, string descripcion, string? motivo = null);
    }

    // Cada creador concreto decide qué elemento se audita
    public class HistorialSolicitudCreator : HistorialCreator
    {
        public override Historial CrearRegistro(int codUsuario, string tipoOperacion,
            int codElemento, string descripcion, string? motivo = null) =>
            new Historial
            {
                CodUsuario = codUsuario,
                TipoOperacion = tipoOperacion,
                ElementoAfectado = "Solicitud",
                CodElemento = codElemento,
                Descripcion = descripcion,
                Motivo = motivo
            };
    }

    public class HistorialOrdenCreator : HistorialCreator
    {
        public override Historial CrearRegistro(int codUsuario, string tipoOperacion,
            int codElemento, string descripcion, string? motivo = null) =>
            new Historial
            {
                CodUsuario = codUsuario,
                TipoOperacion = tipoOperacion,
                ElementoAfectado = "Orden de Compra",
                CodElemento = codElemento,
                Descripcion = descripcion,
                Motivo = motivo
            };
    }

    public class HistorialRecepcionCreator : HistorialCreator
    {
        public override Historial CrearRegistro(int codUsuario, string tipoOperacion,
            int codElemento, string descripcion, string? motivo = null) =>
            new Historial
            {
                CodUsuario = codUsuario,
                TipoOperacion = tipoOperacion,
                ElementoAfectado = "Recepción",
                CodElemento = codElemento,
                Descripcion = descripcion,
                Motivo = motivo
            };
    }
}