﻿namespace Sigaf.Patrones.Facade
{
    public enum EstadoResultado
    {
        Exito,
        Error,              // error de validación: se vuelve al formulario
        OrdenNoDisponible,  // la orden ya fue recibida: se vuelve a la lista
        NoEncontrado
    }

    public record ResultadoRecepcion(EstadoResultado Estado, string Mensaje = "");
}