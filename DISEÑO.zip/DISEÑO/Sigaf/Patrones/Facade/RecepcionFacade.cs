﻿using Microsoft.EntityFrameworkCore;
using Sigaf.Models;

namespace Sigaf.Patrones.Facade
{
    // PATRÓN FACADE: interfaz simple que oculta el cálculo, la transacción,
    // el stock y el historial del proceso de recepción
    public class RecepcionFacade
    {
        private readonly SigafContext _context;

        public RecepcionFacade(SigafContext context)
        {
            _context = context;
        }

        // ---------- Consultas ----------
        public async Task<List<OrdenCompra>> ObtenerPendientesAsync() =>
            await _context.OrdenCompras
                .Include(o => o.CodProveedorNavigation)
                .Include(o => o.CodSolicitudNavigation).ThenInclude(s => s.CodProductoNavigation)
                .Where(o => o.Estado == "Emitida" || o.Estado == "Recibida parcial")
                .OrderBy(o => o.FechaEmision)
                .ToListAsync();

        public async Task<List<Recepcion>> ObtenerRecepcionesAsync() =>
            await _context.Recepcions
                .Include(r => r.CodOrdenNavigation).ThenInclude(o => o.CodSolicitudNavigation).ThenInclude(s => s.CodProductoNavigation)
                .Include(r => r.CodUsuarioReceptorNavigation)
                .OrderByDescending(r => r.FechaRecepcion)
                .ToListAsync();

        public async Task<OrdenCompra?> ObtenerOrdenAsync(int id) =>
            await _context.OrdenCompras
                .Include(o => o.CodProveedorNavigation)
                .Include(o => o.CodSolicitudNavigation).ThenInclude(s => s.CodProductoNavigation)
                .FirstOrDefaultAsync(o => o.CodOrden == id);

        public async Task<decimal> ObtenerYaAceptadoAsync(int codOrden) =>
            await _context.Recepcions
                .Where(r => r.CodOrden == codOrden)
                .SumAsync(r => (decimal?)r.CantidadAceptada) ?? 0;

        // ---------- Registrar recepción (CU6) ----------
        public async Task<ResultadoRecepcion> RegistrarAsync(int codOrden, int codUsuario,
            decimal cantidadRecibida, decimal cantidadDanada, string? motivoDanio, string? observaciones)
        {
            var orden = await ObtenerOrdenAsync(codOrden);
            if (orden == null)
                return new ResultadoRecepcion(EstadoResultado.NoEncontrado);

            // RN-04
            if (orden.Estado != "Emitida" && orden.Estado != "Recibida parcial")
                return new ResultadoRecepcion(EstadoResultado.OrdenNoDisponible,
                    "Esta orden ya fue recibida por completo.");

            var yaAceptado = await ObtenerYaAceptadoAsync(codOrden);
            var pendiente = orden.CantidadPedida - yaAceptado;

            if (cantidadRecibida <= 0)
                return Error("La cantidad recibida debe ser mayor a 0.");
            if (cantidadDanada < 0 || cantidadDanada > cantidadRecibida)
                return Error("La cantidad dañada o incorrecta no puede ser negativa ni mayor a lo recibido.");
            if (cantidadDanada > 0 && string.IsNullOrWhiteSpace(motivoDanio))
                return Error("Indique si lo rechazado está Dañado o es Incorrecto.");

            // RN-12: solo se acepta hasta lo pendiente; el sobrante se rechaza
            var conformes = cantidadRecibida - cantidadDanada;
            var aceptada = Math.Min(conformes, pendiente);
            var exceso = conformes - aceptada;
            var rechazada = cantidadDanada + exceso;

            string? motivoRechazo = null;
            if (rechazada > 0)
                motivoRechazo = cantidadDanada > 0 ? motivoDanio : "Exceso";

            using var tx = await _context.Database.BeginTransactionAsync();
            try
            {
                var recepcion = new Recepcion
                {
                    CodOrden = codOrden,
                    FechaRecepcion = DateTime.Now,
                    CodUsuarioReceptor = codUsuario,
                    CantidadRecibida = cantidadRecibida,
                    CantidadAceptada = aceptada,
                    CantidadRechazada = rechazada,
                    MotivoRechazo = motivoRechazo,
                    Observaciones = string.IsNullOrWhiteSpace(observaciones) ? null : observaciones.Trim(),
                    Estado = "Registrada"
                };
                _context.Recepcions.Add(recepcion);

                orden.Estado = (yaAceptado + aceptada) >= orden.CantidadPedida
                    ? "Recibida completa"
                    : "Recibida parcial";

                await _context.SaveChangesAsync();

                var descripcion = orden.Estado == "Recibida completa"
                    ? "Recepción completa registrada"
                    : "Recepción parcial registrada";
                if (exceso > 0) descripcion = "Recepción con exceso: excedente rechazado";

                _context.Historials.Add(new Historial
                {
                    CodUsuario = codUsuario,
                    TipoOperacion = "Recepción",
                    ElementoAfectado = "Recepción",
                    CodElemento = recepcion.CodRecepcion,
                    Descripcion = descripcion,
                    Motivo = rechazada > 0
                        ? rechazada.ToString("0.##") + " unidades rechazadas (" + motivoRechazo + ")"
                        : null
                });
                await _context.SaveChangesAsync();

                await tx.CommitAsync();

                return new ResultadoRecepcion(EstadoResultado.Exito,
                    "Recepción registrada. Aceptadas: " + aceptada.ToString("0.##")
                    + (rechazada > 0 ? ", rechazadas: " + rechazada.ToString("0.##") : "") + ".");
            }
            catch
            {
                await tx.RollbackAsync();
                return Error("No se pudo registrar la recepción. Intente nuevamente.");
            }
        }

        // ---------- Confirmar recepción y actualizar inventario (CU7) ----------
        public async Task<ResultadoRecepcion> ConfirmarAsync(int codRecepcion, int codUsuario)
        {
            using var tx = await _context.Database.BeginTransactionAsync();
            try
            {
                var r = await _context.Recepcions
                    .Include(x => x.CodOrdenNavigation).ThenInclude(o => o.CodSolicitudNavigation)
                    .ThenInclude(s => s.CodProductoNavigation)
                    .FirstOrDefaultAsync(x => x.CodRecepcion == codRecepcion);

                if (r == null)
                    return new ResultadoRecepcion(EstadoResultado.NoEncontrado);

                if (r.Estado == "Confirmada")   // CU7 A2
                    return Error("El inventario ya fue actualizado para esta recepción.");

                if (r.CantidadAceptada > 0)     // CU7 A3
                    r.CodOrdenNavigation.CodSolicitudNavigation.CodProductoNavigation.StockActual += r.CantidadAceptada;
                r.Estado = "Confirmada";

                _context.Historials.Add(new Historial
                {
                    CodUsuario = codUsuario,
                    TipoOperacion = "Actualización de inventario",
                    ElementoAfectado = "Recepción",
                    CodElemento = r.CodRecepcion,
                    Descripcion = r.CantidadAceptada > 0
                        ? "Inventario actualizado con " + r.CantidadAceptada.ToString("0.##") + " unidades aceptadas"
                        : "Recepción confirmada sin cantidades aceptadas"
                });

                await _context.SaveChangesAsync();
                await tx.CommitAsync();

                return new ResultadoRecepcion(EstadoResultado.Exito,
                    "Recepción confirmada e inventario actualizado.");
            }
            catch
            {
                await tx.RollbackAsync();
                return Error("No fue posible actualizar el inventario.");
            }
        }

        private static ResultadoRecepcion Error(string mensaje) =>
            new ResultadoRecepcion(EstadoResultado.Error, mensaje);
    }
}