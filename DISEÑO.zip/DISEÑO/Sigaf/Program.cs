using Sigaf.Patrones.Facade;
using Microsoft.EntityFrameworkCore;
using Sigaf.Models;

var builder = WebApplication.CreateBuilder(args);

// Conexión a SQL Server
builder.Services.AddDbContext<SigafContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("Sigaf")));
builder.Services.AddScoped<RecepcionFacade>();

// Autenticación por cookies (login y roles)
builder.Services.AddAuthentication("SigafCookie")
    .AddCookie("SigafCookie", options =>
    {
        options.LoginPath = "/Account/Login";
        options.AccessDeniedPath = "/Account/AccesoDenegado";
    });

// Add services to the container.
builder.Services.AddControllersWithViews();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

app.UseAuthentication();
app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();