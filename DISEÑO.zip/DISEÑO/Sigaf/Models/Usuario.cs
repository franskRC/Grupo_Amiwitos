﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace Sigaf.Models;

[Table("Usuario")]
[Index("NombreUsuario", Name = "UQ_Usuario_NombreUsuario", IsUnique = true)]
public partial class Usuario
{
    [Key]
    public int CodUsuario { get; set; }

    [StringLength(80)]
    public string Nombres { get; set; } = null!;

    [StringLength(80)]
    public string Apellidos { get; set; } = null!;

    [StringLength(40)]
    public string NombreUsuario { get; set; } = null!;

    [StringLength(255)]
    public string Contraseña { get; set; } = null!;

    [StringLength(40)]
    public string Rol { get; set; } = null!;

    [StringLength(10)]
    public string Estado { get; set; } = null!;

    [InverseProperty("CodUsuarioNavigation")]
    public virtual ICollection<Historial> Historials { get; set; } = new List<Historial>();

    [InverseProperty("CodUsuarioEmisorNavigation")]
    public virtual ICollection<OrdenCompra> OrdenCompras { get; set; } = new List<OrdenCompra>();

    [InverseProperty("CodUsuarioReceptorNavigation")]
    public virtual ICollection<Recepcion> Recepcions { get; set; } = new List<Recepcion>();

    [InverseProperty("CodUsuarioEvaluadorNavigation")]
    public virtual ICollection<Solicitud> SolicitudCodUsuarioEvaluadorNavigations { get; set; } = new List<Solicitud>();

    [InverseProperty("CodUsuarioSolicitanteNavigation")]
    public virtual ICollection<Solicitud> SolicitudCodUsuarioSolicitanteNavigations { get; set; } = new List<Solicitud>();
}
