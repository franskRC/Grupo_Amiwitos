﻿using System.ComponentModel.DataAnnotations;

namespace Sigaf.Models
{
    public class LoginViewModel
    {
        [Required(ErrorMessage = "Ingrese su usuario")]
        public string NombreUsuario { get; set; } = "";

        [Required(ErrorMessage = "Ingrese su contraseña")]
        [DataType(DataType.Password)]
        public string Clave { get; set; } = "";
    }
}