﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace Sigaf.Models;

[Table("Solicitud")]
public partial class Solicitud
{
    [Key]
    public int CodSolicitud { get; set; }

    [Column(TypeName = "datetime")]
    public DateTime FechaRegistro { get; set; }

    public int CodUsuarioSolicitante { get; set; }

    public int CodProducto { get; set; }

    [Column(TypeName = "decimal(10, 2)")]
    public decimal CantidadSolicitada { get; set; }

    [StringLength(255)]
    public string Justificacion { get; set; } = null!;

    [StringLength(30)]
    public string Estado { get; set; } = null!;

    public int? CodUsuarioEvaluador { get; set; }

    [Column(TypeName = "datetime")]
    public DateTime? FechaEvaluacion { get; set; }

    [StringLength(255)]
    public string? MotivoEvaluacion { get; set; }

    [ForeignKey("CodProducto")]
    [InverseProperty("Solicituds")]
    public virtual Producto CodProductoNavigation { get; set; } = null!;

    [ForeignKey("CodUsuarioEvaluador")]
    [InverseProperty("SolicitudCodUsuarioEvaluadorNavigations")]
    public virtual Usuario? CodUsuarioEvaluadorNavigation { get; set; }

    [ForeignKey("CodUsuarioSolicitante")]
    [InverseProperty("SolicitudCodUsuarioSolicitanteNavigations")]
    public virtual Usuario CodUsuarioSolicitanteNavigation { get; set; } = null!;

    [InverseProperty("CodSolicitudNavigation")]
    public virtual OrdenCompra? OrdenCompra { get; set; }
}
