﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace Sigaf.Models;

[Table("OrdenCompra")]
[Index("CodSolicitud", Name = "UQ_Orden_Solicitud", IsUnique = true)]
public partial class OrdenCompra
{
    [Key]

    public int CodOrden { get; set; }

    public int CodSolicitud { get; set; }

    public int CodProveedor { get; set; }

    public int CodUsuarioEmisor { get; set; }

    [Column(TypeName = "datetime")]
    public DateTime FechaEmision { get; set; }

    [Column(TypeName = "decimal(10, 2)")]
    public decimal CantidadPedida { get; set; }

    [StringLength(20)]
    public string Estado { get; set; } = null!;

    [StringLength(255)]
    public string? Observaciones { get; set; }

    [ForeignKey("CodProveedor")]
    [InverseProperty("OrdenCompras")]
    public virtual Proveedor CodProveedorNavigation { get; set; } = null!;

    [ForeignKey("CodSolicitud")]
    [InverseProperty("OrdenCompra")]
    public virtual Solicitud CodSolicitudNavigation { get; set; } = null!;

    [ForeignKey("CodUsuarioEmisor")]
    [InverseProperty("OrdenCompras")]
    public virtual Usuario CodUsuarioEmisorNavigation { get; set; } = null!;

    [InverseProperty("CodOrdenNavigation")]
    [Column(TypeName = "decimal(10, 2)")]
    public decimal PrecioUnitario { get; set; }

    [Column(TypeName = "decimal(12, 2)")]
    [DatabaseGenerated(DatabaseGeneratedOption.Computed)]
    public decimal PrecioTotal { get; set; }
    public virtual ICollection<Recepcion> Recepcions { get; set; } = new List<Recepcion>();
}
