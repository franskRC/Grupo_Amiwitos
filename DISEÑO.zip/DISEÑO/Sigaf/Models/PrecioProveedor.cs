﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Sigaf.Models;

[Table("PrecioProveedor")]
public partial class PrecioProveedor
{
    [Key]
    public int CodPrecio { get; set; }

    public int CodProducto { get; set; }

    public int CodProveedor { get; set; }

    [Column(TypeName = "decimal(10, 2)")]
    public decimal PrecioUnitario { get; set; }

    [Column(TypeName = "datetime")]
    public DateTime FechaActualizacion { get; set; }

    [StringLength(10)]
    public string Estado { get; set; } = null!;

    [ForeignKey("CodProducto")]
    public virtual Producto CodProductoNavigation { get; set; } = null!;

    [ForeignKey("CodProveedor")]
    public virtual Proveedor CodProveedorNavigation { get; set; } = null!;
}