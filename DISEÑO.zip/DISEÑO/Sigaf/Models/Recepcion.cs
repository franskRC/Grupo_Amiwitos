﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace Sigaf.Models;

[Table("Recepcion")]
public partial class Recepcion
{
    [Key]
    public int CodRecepcion { get; set; }

    public int CodOrden { get; set; }

    [Column(TypeName = "datetime")]
    public DateTime FechaRecepcion { get; set; }

    public int CodUsuarioReceptor { get; set; }

    [Column(TypeName = "decimal(10, 2)")]
    public decimal CantidadRecibida { get; set; }

    [Column(TypeName = "decimal(10, 2)")]
    public decimal CantidadAceptada { get; set; }

    [Column(TypeName = "decimal(10, 2)")]
    public decimal CantidadRechazada { get; set; }

    [StringLength(20)]
    public string? MotivoRechazo { get; set; }

    [StringLength(255)]
    public string? Observaciones { get; set; }

    [StringLength(15)]
    public string Estado { get; set; } = null!;

    [ForeignKey("CodOrden")]
    [InverseProperty("Recepcions")]
    public virtual OrdenCompra CodOrdenNavigation { get; set; } = null!;

    [ForeignKey("CodUsuarioReceptor")]
    [InverseProperty("Recepcions")]
    public virtual Usuario CodUsuarioReceptorNavigation { get; set; } = null!;
}
