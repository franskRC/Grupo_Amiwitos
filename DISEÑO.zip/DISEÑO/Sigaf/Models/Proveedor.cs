﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace Sigaf.Models;

[Table("Proveedor")]
public partial class Proveedor
{
    [Key]
    public int CodProveedor { get; set; }

    [StringLength(100)]
    public string Nombre { get; set; } = null!;

    [StringLength(20)]
    public string? Telefono { get; set; }

    [StringLength(100)]
    public string? Correo { get; set; }

    [StringLength(10)]
    public string Estado { get; set; } = null!;

    [InverseProperty("CodProveedorNavigation")]
    public virtual ICollection<OrdenCompra> OrdenCompras { get; set; } = new List<OrdenCompra>();
    public virtual ICollection<PrecioProveedor> PrecioProveedors { get; set; } = new List<PrecioProveedor>();
}
