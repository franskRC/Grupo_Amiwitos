﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace Sigaf.Models;

public partial class SigafContext : DbContext
{
    public SigafContext()
    {
    }

    public SigafContext(DbContextOptions<SigafContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Historial> Historials { get; set; }

    public virtual DbSet<OrdenCompra> OrdenCompras { get; set; }

    public virtual DbSet<Producto> Productos { get; set; }

    public virtual DbSet<Proveedor> Proveedors { get; set; }

    public virtual DbSet<Recepcion> Recepcions { get; set; }

    public virtual DbSet<Solicitud> Solicituds { get; set; }

    public virtual DbSet<Usuario> Usuarios { get; set; }
    public virtual DbSet<PrecioProveedor> PrecioProveedors { get; set; }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Historial>(entity =>
        {
            entity.HasKey(e => e.CodHistorial).HasName("PK__Historia__AD73F5B9027552D1");

            entity.ToTable("Historial", tb => tb.HasTrigger("TR_Historial_SoloInsercion"));

            entity.Property(e => e.FechaHora).HasDefaultValueSql("(getdate())");

            entity.HasOne(d => d.CodUsuarioNavigation).WithMany(p => p.Historials)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Historial_Usuario");
        });

        modelBuilder.Entity<OrdenCompra>(entity =>
        {
            entity.HasKey(e => e.CodOrden).HasName("PK__OrdenCom__48B0905B2CD43561");

            entity.Property(e => e.Estado).HasDefaultValue("Emitida");
            entity.Property(e => e.FechaEmision).HasDefaultValueSql("(getdate())");

            entity.HasOne(d => d.CodProveedorNavigation).WithMany(p => p.OrdenCompras)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Orden_Proveedor");

            entity.HasOne(d => d.CodSolicitudNavigation).WithOne(p => p.OrdenCompra)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Orden_Solicitud");

            entity.HasOne(d => d.CodUsuarioEmisorNavigation).WithMany(p => p.OrdenCompras)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Orden_Emisor");
        });

        modelBuilder.Entity<Producto>(entity =>
        {
            entity.HasKey(e => e.CodProducto).HasName("PK__Producto__0D06FDF35C4C950E");

            entity.Property(e => e.Estado).HasDefaultValue("Activo");
        });

        modelBuilder.Entity<Proveedor>(entity =>
        {
            entity.HasKey(e => e.CodProveedor).HasName("PK__Proveedo__BFBE6B072DDD1BED");

            entity.Property(e => e.Estado).HasDefaultValue("Activo");
        });

        modelBuilder.Entity<Recepcion>(entity =>
        {
            entity.HasKey(e => e.CodRecepcion).HasName("PK__Recepcio__28C3DCF111836EC0");

            entity.Property(e => e.Estado).HasDefaultValue("Registrada");
            entity.Property(e => e.FechaRecepcion).HasDefaultValueSql("(getdate())");

            entity.HasOne(d => d.CodOrdenNavigation).WithMany(p => p.Recepcions)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Recepcion_Orden");

            entity.HasOne(d => d.CodUsuarioReceptorNavigation).WithMany(p => p.Recepcions)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Recepcion_Receptor");
        });

        modelBuilder.Entity<Solicitud>(entity =>
        {
            entity.HasKey(e => e.CodSolicitud).HasName("PK__Solicitu__307A4CAF6AB1DDB3");

            entity.Property(e => e.Estado).HasDefaultValue("Borrador");
            entity.Property(e => e.FechaRegistro).HasDefaultValueSql("(getdate())");

            entity.HasOne(d => d.CodProductoNavigation).WithMany(p => p.Solicituds)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Solicitud_Producto");

            entity.HasOne(d => d.CodUsuarioEvaluadorNavigation).WithMany(p => p.SolicitudCodUsuarioEvaluadorNavigations).HasConstraintName("FK_Solicitud_Evaluador");

            entity.HasOne(d => d.CodUsuarioSolicitanteNavigation).WithMany(p => p.SolicitudCodUsuarioSolicitanteNavigations)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Solicitud_Solicitante");
        });

        modelBuilder.Entity<Usuario>(entity =>
        {
            entity.HasKey(e => e.CodUsuario).HasName("PK__Usuario__FC30C2C478DB1C7A");

            entity.Property(e => e.Estado).HasDefaultValue("Activo");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
