﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace Sigaf.Models;

[Table("Producto")]
public partial class Producto
{
    [Key]
    public int CodProducto { get; set; }

    [StringLength(100)]
    public string Nombre { get; set; } = null!;

    [StringLength(15)]
    public string Tipo { get; set; } = null!;

    [StringLength(20)]
    public string UnidadMedida { get; set; } = null!;

    [Column(TypeName = "decimal(10, 2)")]
    public decimal StockActual { get; set; }

    [StringLength(10)]
    public string Estado { get; set; } = null!;

    [InverseProperty("CodProductoNavigation")]
    public virtual ICollection<Solicitud> Solicituds { get; set; } = new List<Solicitud>();
    public virtual ICollection<PrecioProveedor> PrecioProveedors { get; set; } = new List<PrecioProveedor>();
}
