﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace Sigaf.Models;

[Table("Historial")]
public partial class Historial
{
    [Key]
    public int CodHistorial { get; set; }

    public int CodUsuario { get; set; }

    [Column(TypeName = "datetime")]
    public DateTime FechaHora { get; set; }

    [StringLength(30)]
    public string TipoOperacion { get; set; } = null!;

    [StringLength(20)]
    public string ElementoAfectado { get; set; } = null!;

    public int CodElemento { get; set; }

    [StringLength(255)]
    public string Descripcion { get; set; } = null!;

    [StringLength(255)]
    public string? Motivo { get; set; }

    [ForeignKey("CodUsuario")]
    [InverseProperty("Historials")]
    public virtual Usuario CodUsuarioNavigation { get; set; } = null!;
}
