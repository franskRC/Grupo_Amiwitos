﻿using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Sigaf.Models;
using Sigaf.Patrones.Factory;

namespace Sigaf.Controllers
{
    [Authorize(Roles = "Responsable de Abastecimiento")]
    public class OrdenesController : Controller
    {
        private readonly SigafContext _context;

        public OrdenesController(SigafContext context)
        {
            _context = context;
        }

        private int UsuarioActual() =>
            int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)!.Value);

        // Lista: pendientes de emitir + órdenes emitidas
        public async Task<IActionResult> Index()
        {
            var conOrden = _context.OrdenCompras.Select(o => o.CodSolicitud);

            ViewBag.Autorizadas = await _context.Solicituds
                .Include(s => s.CodProductoNavigation)
                .Include(s => s.CodUsuarioSolicitanteNavigation)
                .Where(s => s.Estado == "Autorizada" && !conOrden.Contains(s.CodSolicitud))
                .OrderBy(s => s.FechaRegistro)
                .ToListAsync();

            var ordenes = await _context.OrdenCompras
                .Include(o => o.CodProveedorNavigation)
                .Include(o => o.CodSolicitudNavigation).ThenInclude(s => s.CodProductoNavigation)
                .OrderByDescending(o => o.FechaEmision)
                .ToListAsync();

            return View(ordenes);
        }

        [HttpGet]
        public async Task<IActionResult> Emitir(int id)
        {
            var s = await _context.Solicituds
                .Include(x => x.CodProductoNavigation)
                .FirstOrDefaultAsync(x => x.CodSolicitud == id);
            if (s == null) return NotFound();

            // RN-03
            if (s.Estado != "Autorizada" || await _context.OrdenCompras.AnyAsync(o => o.CodSolicitud == id))
            {
                TempData["Error"] = "Solo se puede emitir orden de una solicitud autorizada y sin orden previa.";
                return RedirectToAction(nameof(Index));
            }

            CargarProveedores();
            ViewBag.Precios = await _context.PrecioProveedors
                .Where(p => p.CodProducto == s.CodProducto && p.Estado == "Activo")
                .ToDictionaryAsync(p => p.CodProveedor, p => p.PrecioUnitario);
            return View(s);
        }

        [HttpPost]
        public async Task<IActionResult> Emitir(int id, int codProveedor, decimal precioUnitario, string? observaciones)
        {
            var s = await _context.Solicituds
                .Include(x => x.CodProductoNavigation)
                .FirstOrDefaultAsync(x => x.CodSolicitud == id);
            if (s == null) return NotFound();

            // RN-03
            if (s.Estado != "Autorizada" || await _context.OrdenCompras.AnyAsync(o => o.CodSolicitud == id))
            {
                TempData["Error"] = "Solo se puede emitir orden de una solicitud autorizada y sin orden previa.";
                return RedirectToAction(nameof(Index));
            }

            var proveedor = await _context.Proveedors.FindAsync(codProveedor);
            if (proveedor == null || proveedor.Estado != "Activo")
            {
                TempData["Error"] = "Seleccione un proveedor activo.";
                return RedirectToAction(nameof(Emitir), new { id });
            }

            if (precioUnitario <= 0)
            {
                TempData["Error"] = "El precio unitario debe ser mayor a 0.";
                return RedirectToAction(nameof(Emitir), new { id });
            }

            using var tx = await _context.Database.BeginTransactionAsync();
            try
            {
                var orden = new OrdenCompra
                {
                    CodSolicitud = s.CodSolicitud,
                    CodProveedor = codProveedor,
                    CodUsuarioEmisor = UsuarioActual(),
                    FechaEmision = DateTime.Now,
                    CantidadPedida = s.CantidadSolicitada,
                    PrecioUnitario = precioUnitario,   // PrecioTotal lo calcula SQL Server
                    Estado = "Emitida",
                    Observaciones = string.IsNullOrWhiteSpace(observaciones) ? null : observaciones.Trim()
                };

                _context.OrdenCompras.Add(orden);
                await _context.SaveChangesAsync();

                _context.Historials.Add(new HistorialOrdenCreator().CrearRegistro(
                    UsuarioActual(), "Emisión", orden.CodOrden,
                    "Orden de compra emitida al proveedor " + proveedor.Nombre));
                await _context.SaveChangesAsync();

                await tx.CommitAsync();
                TempData["Mensaje"] = "Orden de compra N° " + orden.CodOrden + " emitida. Total: " + orden.PrecioTotal.ToString("0.00");
            }
            catch
            {
                await tx.RollbackAsync();
                TempData["Error"] = "No fue posible registrar la orden de compra.";
                return RedirectToAction(nameof(Emitir), new { id });
            }

            return RedirectToAction(nameof(Index));
        }

        private void CargarProveedores()
        {
            var activos = _context.Proveedors
                .Where(p => p.Estado == "Activo")
                .OrderBy(p => p.Nombre)
                .ToList();
            ViewBag.Proveedores = new SelectList(activos, "CodProveedor", "Nombre");
        }
    }
}