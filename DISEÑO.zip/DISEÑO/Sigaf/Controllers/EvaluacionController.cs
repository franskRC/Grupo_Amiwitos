﻿using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Sigaf.Models;
using Sigaf.Patrones.Strategy;

namespace Sigaf.Controllers
{
    [Authorize(Roles = "Responsable de Abastecimiento")]
    public class EvaluacionController : Controller
    {
        private readonly SigafContext _context;

        // PATRÓN STRATEGY: cada decisión es una estrategia intercambiable
        private static readonly Dictionary<string, IDecisionEvaluacion> Decisiones = new()
        {
            ["autorizar"] = new AutorizarDecision(),
            ["rechazar"] = new RechazarDecision(),
            ["devolver"] = new DevolverDecision()
        };

        public EvaluacionController(SigafContext context)
        {
            _context = context;
        }

        private int UsuarioActual() =>
            int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)!.Value);

        // REVISIÓN: bandeja de pendientes
        public async Task<IActionResult> Index()
        {
            var pendientes = await _context.Solicituds
                .Include(s => s.CodProductoNavigation)
                .Include(s => s.CodUsuarioSolicitanteNavigation)
                .Where(s => s.Estado == "Pendiente de evaluación")
                .OrderBy(s => s.FechaRegistro)
                .ToListAsync();
            return View(pendientes);
        }

        // EVALUACIÓN: detalle y decisión
        [HttpGet]
        public async Task<IActionResult> Evaluar(int id)
        {
            var s = await _context.Solicituds
                .Include(x => x.CodProductoNavigation)
                .Include(x => x.CodUsuarioSolicitanteNavigation)
                .FirstOrDefaultAsync(x => x.CodSolicitud == id);

            if (s == null) return NotFound();

            if (s.Estado != "Pendiente de evaluación")
            {
                TempData["Error"] = "Esta solicitud ya no está pendiente de evaluación.";
                return RedirectToAction(nameof(Index));
            }

            return View(s);
        }

        [HttpPost]
        public async Task<IActionResult> Evaluar(int id, string decision, string? motivo)
        {
            var s = await _context.Solicituds
                .Include(x => x.CodProductoNavigation)
                .FirstOrDefaultAsync(x => x.CodSolicitud == id);

            if (s == null) return NotFound();

            if (s.Estado != "Pendiente de evaluación")
            {
                TempData["Error"] = "Esta solicitud ya no está pendiente de evaluación.";
                return RedirectToAction(nameof(Index));
            }

            // Se elige la estrategia según el botón presionado
            if (!Decisiones.TryGetValue(decision ?? "", out var estrategia))
                return BadRequest();

            motivo = motivo?.Trim();

            var error = estrategia.Validar(s, motivo);
            if (error != null)
            {
                TempData["Error"] = error;
                return RedirectToAction(nameof(Evaluar), new { id });
            }

            estrategia.Aplicar(s, motivo);
            Registrar(estrategia.TipoOperacion, s.CodSolicitud, estrategia.Descripcion, s.MotivoEvaluacion);

            s.CodUsuarioEvaluador = UsuarioActual();
            s.FechaEvaluacion = DateTime.Now;

            await _context.SaveChangesAsync();

            TempData["Mensaje"] = estrategia.MensajeExito;
            return RedirectToAction(nameof(Index));
        }

        private void Registrar(string tipo, int codSolicitud, string descripcion, string? motivo)
        {
            _context.Historials.Add(new Historial
            {
                CodUsuario = UsuarioActual(),
                TipoOperacion = tipo,
                ElementoAfectado = "Solicitud",
                CodElemento = codSolicitud,
                Descripcion = descripcion,
                Motivo = motivo
            });
        }
    }
}