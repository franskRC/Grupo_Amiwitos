﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Sigaf.Models;

namespace Sigaf.Controllers
{
    [Authorize]
    public class HistorialController : Controller
    {
        private readonly SigafContext _context;

        public HistorialController(SigafContext context)
        {
            _context = context;
        }

        public async Task<IActionResult> Index(string? elemento)
        {
            var consulta = _context.Historials
                .Include(h => h.CodUsuarioNavigation)
                .AsQueryable();

            if (!string.IsNullOrWhiteSpace(elemento))
                consulta = consulta.Where(h => h.ElementoAfectado == elemento);

            var lista = await consulta
                .OrderByDescending(h => h.FechaHora)
                .Take(200)
                .ToListAsync();

            ViewData["Elemento"] = elemento;
            return View(lista);
        }
    }
}