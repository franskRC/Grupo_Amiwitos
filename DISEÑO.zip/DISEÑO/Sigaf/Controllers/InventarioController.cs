﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Sigaf.Models;

namespace Sigaf.Controllers
{
    [Authorize]
    public class InventarioController : Controller
    {
        private readonly SigafContext _context;

        public InventarioController(SigafContext context)
        {
            _context = context;
        }

        public async Task<IActionResult> Index(string? buscar, string? tipo, bool soloActivos = true)
        {
            var consulta = _context.Productos.AsQueryable();

            if (!string.IsNullOrWhiteSpace(buscar))
                consulta = consulta.Where(p => p.Nombre.Contains(buscar));

            if (!string.IsNullOrWhiteSpace(tipo))
                consulta = consulta.Where(p => p.Tipo == tipo);

            if (soloActivos)
                consulta = consulta.Where(p => p.Estado == "Activo");

            var productos = await consulta.OrderBy(p => p.Nombre).ToListAsync();

            ViewData["Buscar"] = buscar;
            ViewData["Tipo"] = tipo;
            ViewData["SoloActivos"] = soloActivos;

            return View(productos);
        }
    }
}