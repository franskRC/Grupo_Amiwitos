﻿using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Sigaf.Models;

namespace Sigaf.Controllers
{
    public class AccountController : Controller
    {
        private readonly SigafContext _context;

        public AccountController(SigafContext context)
        {
            _context = context;
        }

        [HttpGet]
        public IActionResult Login()
        {
            return View(new LoginViewModel());
        }

        [HttpPost]
        public async Task<IActionResult> Login(LoginViewModel model)
        {
            if (!ModelState.IsValid) return View(model);

            var hash = Convert.ToHexString(SHA256.HashData(Encoding.Unicode.GetBytes(model.Clave)));

            var usuario = await _context.Usuarios.FirstOrDefaultAsync(u =>
                u.NombreUsuario == model.NombreUsuario &&
                u.Contraseña == hash &&
                u.Estado == "Activo");

            if (usuario == null)
            {
                ModelState.AddModelError("", "Usuario o contraseña incorrectos.");
                return View(model);
            }

            var claims = new List<Claim>
            {
                new Claim(ClaimTypes.NameIdentifier, usuario.CodUsuario.ToString()),
                new Claim(ClaimTypes.Name, usuario.Nombres + " " + usuario.Apellidos),
                new Claim(ClaimTypes.Role, usuario.Rol)
            };

            var identity = new ClaimsIdentity(claims, "SigafCookie");
            await HttpContext.SignInAsync("SigafCookie", new ClaimsPrincipal(identity));

            return RedirectToAction("Index", "Home");
        }

        public async Task<IActionResult> Logout()
        {
            await HttpContext.SignOutAsync("SigafCookie");
            return RedirectToAction("Login");
        }

        public IActionResult AccesoDenegado()
        {
            return View();
        }
    }
}