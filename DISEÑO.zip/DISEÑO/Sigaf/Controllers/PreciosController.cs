﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Sigaf.Models;

namespace Sigaf.Controllers
{
    [Authorize(Roles = "Responsable de Abastecimiento")]
    public class PreciosController : Controller
    {
        private readonly SigafContext _context;

        public PreciosController(SigafContext context)
        {
            _context = context;
        }

        private void CargarListas()
        {
            ViewBag.Productos = new SelectList(
                _context.Productos.Where(p => p.Estado == "Activo").OrderBy(p => p.Nombre).ToList(),
                "CodProducto", "Nombre");
            ViewBag.Proveedores = new SelectList(
                _context.Proveedors.Where(p => p.Estado == "Activo").OrderBy(p => p.Nombre).ToList(),
                "CodProveedor", "Nombre");
        }

        public async Task<IActionResult> Index()
        {
            var lista = await _context.PrecioProveedors
                .Include(p => p.CodProductoNavigation)
                .Include(p => p.CodProveedorNavigation)
                .OrderBy(p => p.CodProductoNavigation.Nombre)
                .ThenBy(p => p.CodProveedorNavigation.Nombre)
                .ToListAsync();
            return View(lista);
        }

        [HttpGet]
        public IActionResult Guardar()
        {
            CargarListas();
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Guardar(int codProducto, int codProveedor, decimal precioUnitario)
        {
            if (codProducto == 0 || codProveedor == 0 || precioUnitario <= 0)
            {
                TempData["Error"] = "Seleccione producto y proveedor, y un precio mayor a 0.";
                return RedirectToAction(nameof(Guardar));
            }

            var precio = await _context.PrecioProveedors
                .FirstOrDefaultAsync(x => x.CodProducto == codProducto && x.CodProveedor == codProveedor);

            if (precio == null)
            {
                _context.PrecioProveedors.Add(new PrecioProveedor
                {
                    CodProducto = codProducto,
                    CodProveedor = codProveedor,
                    PrecioUnitario = precioUnitario,
                    FechaActualizacion = DateTime.Now,
                    Estado = "Activo"
                });
            }
            else
            {
                precio.PrecioUnitario = precioUnitario;
                precio.FechaActualizacion = DateTime.Now;
                precio.Estado = "Activo";
            }

            await _context.SaveChangesAsync();
            TempData["Mensaje"] = "Precio guardado.";
            return RedirectToAction(nameof(Index));
        }
    }
}