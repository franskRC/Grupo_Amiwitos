﻿using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Sigaf.Models;
using Sigaf.Patrones.Factory;

namespace Sigaf.Controllers
{
    [Authorize(Roles = "Operador de Almacén")]
    public class SolicitudesController : Controller
    {
        private readonly SigafContext _context;

        public SolicitudesController(SigafContext context)
        {
            _context = context;
        }

        private int UsuarioActual() =>
            int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)!.Value);

        private void CargarProductos(int? seleccionado = null)
        {
            var productos = _context.Productos
                .Where(p => p.Estado == "Activo")
                .OrderBy(p => p.Nombre)
                .ToList();
            ViewBag.Productos = new SelectList(productos, "CodProducto", "Nombre", seleccionado);
        }

        private void Registrar(string tipo, int codSolicitud, string descripcion, string? motivo = null)
        {
            _context.Historials.Add(new HistorialSolicitudCreator()
                .CrearRegistro(UsuarioActual(), tipo, codSolicitud, descripcion, motivo));
        }

        // Lista de mis solicitudes
        public async Task<IActionResult> Index()
        {
            var lista = await _context.Solicituds
                .Include(s => s.CodProductoNavigation)
                .Where(s => s.CodUsuarioSolicitante == UsuarioActual())
                .OrderByDescending(s => s.FechaRegistro)
                .ToListAsync();
            return View(lista);
        }

        [HttpGet]
        public IActionResult Crear()
        {
            CargarProductos();
            return View(new Solicitud());
        }

        [HttpPost]
        public async Task<IActionResult> Crear(Solicitud model, string accion)
        {
            ModelState.Remove("CodProductoNavigation");
            ModelState.Remove("CodUsuarioSolicitanteNavigation");
            ModelState.Remove("Estado");

            if (model.CantidadSolicitada <= 0)
                ModelState.AddModelError("CantidadSolicitada", "La cantidad debe ser mayor a 0.");

            if (!ModelState.IsValid)
            {
                CargarProductos(model.CodProducto);
                return View(model);
            }

            model.CodUsuarioSolicitante = UsuarioActual();
            model.FechaRegistro = DateTime.Now;
            model.Estado = accion == "enviar" ? "Pendiente de evaluación" : "Borrador";

            _context.Solicituds.Add(model);
            await _context.SaveChangesAsync();

            Registrar("Creación", model.CodSolicitud, "Solicitud de abastecimiento registrada");
            if (accion == "enviar")
                Registrar("Envío", model.CodSolicitud, "Solicitud enviada a evaluación");
            await _context.SaveChangesAsync();

            TempData["Mensaje"] = accion == "enviar"
                ? "Solicitud enviada a evaluación."
                : "Borrador guardado.";
            return RedirectToAction(nameof(Index));
        }

        [HttpGet]
        public async Task<IActionResult> Editar(int id)
        {
            var s = await _context.Solicituds.FindAsync(id);
            if (s == null || s.CodUsuarioSolicitante != UsuarioActual()) return NotFound();

            // RN-07
            if (s.Estado != "Borrador" && s.Estado != "Devuelta para corrección")
            {
                TempData["Error"] = "Solo se puede modificar una solicitud en Borrador o Devuelta para corrección.";
                return RedirectToAction(nameof(Index));
            }

            CargarProductos(s.CodProducto);
            return View(s);
        }

        [HttpPost]
        public async Task<IActionResult> Editar(int id, Solicitud model, string accion)
        {
            var s = await _context.Solicituds.FindAsync(id);
            if (s == null || s.CodUsuarioSolicitante != UsuarioActual()) return NotFound();

            // RN-07
            if (s.Estado != "Borrador" && s.Estado != "Devuelta para corrección")
            {
                TempData["Error"] = "Solo se puede modificar una solicitud en Borrador o Devuelta para corrección.";
                return RedirectToAction(nameof(Index));
            }

            ModelState.Remove("CodProductoNavigation");
            ModelState.Remove("CodUsuarioSolicitanteNavigation");
            ModelState.Remove("Estado");

            if (model.CantidadSolicitada <= 0)
                ModelState.AddModelError("CantidadSolicitada", "La cantidad debe ser mayor a 0.");

            if (!ModelState.IsValid)
            {
                model.CodSolicitud = id;
                CargarProductos(model.CodProducto);
                return View(model);
            }

            var eraDevuelta = s.Estado == "Devuelta para corrección";

            s.CodProducto = model.CodProducto;
            s.CantidadSolicitada = model.CantidadSolicitada;
            s.Justificacion = model.Justificacion;

            if (accion == "enviar")
            {
                // RN-09: vuelve a Pendiente de evaluación
                s.Estado = "Pendiente de evaluación";
                s.MotivoEvaluacion = null;
                s.CodUsuarioEvaluador = null;
                s.FechaEvaluacion = null;
                Registrar("Envío", s.CodSolicitud,
                    eraDevuelta ? "Solicitud corregida y reenviada a evaluación" : "Solicitud enviada a evaluación");
            }
            else
            {
                Registrar("Modificación", s.CodSolicitud, "Solicitud modificada");
            }

            await _context.SaveChangesAsync();

            TempData["Mensaje"] = accion == "enviar"
                ? "Solicitud enviada a evaluación."
                : "Cambios guardados.";
            return RedirectToAction(nameof(Index));
        }
    }
}