﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Sigaf.Models;

namespace Sigaf.Controllers
{
    [Authorize]
    public class ReportesController : Controller
    {
        private readonly SigafContext _context;

        public ReportesController(SigafContext context)
        {
            _context = context;
        }

        public async Task<IActionResult> Index()
        {
            ViewBag.Solicitudes = await _context.Solicituds
                .GroupBy(s => s.Estado)
                .Select(g => new { g.Key, N = g.Count() })
                .ToDictionaryAsync(x => x.Key, x => x.N);

            ViewBag.Ordenes = await _context.OrdenCompras
                .GroupBy(o => o.Estado)
                .Select(g => new { g.Key, N = g.Count() })
                .ToDictionaryAsync(x => x.Key, x => x.N);

            return View();
        }
    }
}