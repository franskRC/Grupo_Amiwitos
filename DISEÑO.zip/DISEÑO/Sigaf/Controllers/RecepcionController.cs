﻿using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Sigaf.Patrones.Facade;

namespace Sigaf.Controllers
{
    [Authorize(Roles = "Responsable de Recepción")]
    public class RecepcionController : Controller
    {
        private readonly RecepcionFacade _facade;

        public RecepcionController(RecepcionFacade facade)
        {
            _facade = facade;
        }

        private int UsuarioActual() =>
            int.Parse(User.FindFirst(ClaimTypes.NameIdentifier)!.Value);

        // Órdenes pendientes de recibir + recepciones registradas
        public async Task<IActionResult> Index()
        {
            ViewBag.Pendientes = await _facade.ObtenerPendientesAsync();
            return View(await _facade.ObtenerRecepcionesAsync());
        }

        [HttpGet]
        public async Task<IActionResult> Registrar(int id)
        {
            var orden = await _facade.ObtenerOrdenAsync(id);
            if (orden == null) return NotFound();

            // RN-04
            if (orden.Estado != "Emitida" && orden.Estado != "Recibida parcial")
            {
                TempData["Error"] = "Esta orden ya fue recibida por completo.";
                return RedirectToAction(nameof(Index));
            }

            ViewBag.YaAceptado = await _facade.ObtenerYaAceptadoAsync(id);
            return View(orden);
        }

        [HttpPost]
        public async Task<IActionResult> Registrar(int id, decimal cantidadRecibida, decimal cantidadDanada,
            string? motivoDanio, string? observaciones)
        {
            var r = await _facade.RegistrarAsync(id, UsuarioActual(),
                cantidadRecibida, cantidadDanada, motivoDanio, observaciones);

            switch (r.Estado)
            {
                case EstadoResultado.NoEncontrado:
                    return NotFound();

                case EstadoResultado.OrdenNoDisponible:
                    TempData["Error"] = r.Mensaje;
                    return RedirectToAction(nameof(Index));

                case EstadoResultado.Error:
                    TempData["Error"] = r.Mensaje;
                    return RedirectToAction(nameof(Registrar), new { id });

                default:
                    TempData["Mensaje"] = r.Mensaje;
                    return RedirectToAction(nameof(Index));
            }
        }

        [HttpPost, ValidateAntiForgeryToken]
        public async Task<IActionResult> Confirmar(int id)
        {
            var r = await _facade.ConfirmarAsync(id, UsuarioActual());

            if (r.Estado == EstadoResultado.NoEncontrado) return NotFound();

            if (r.Estado == EstadoResultado.Exito)
                TempData["Mensaje"] = r.Mensaje;
            else
                TempData["Error"] = r.Mensaje;

            return RedirectToAction(nameof(Index));
        }
    }
}