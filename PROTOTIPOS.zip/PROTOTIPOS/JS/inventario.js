// ==========================================
// CONTROL DE ACCESO Y SEGURIDAD (RF10 / RNF01)
// ==========================================
var sesionGuardada = sessionStorage.getItem("sesionActiva");

if (!sesionGuardada) {
    alert("Acceso denegado: debe iniciar sesión primero.");
    window.location.href = "login.html";
} else {
    var usuarioActual = JSON.parse(sesionGuardada);

    // Solo el Operador de Almacén puede estar aquí
    if (usuarioActual.rol !== "Operador de Almacén") {
        alert("Acceso no autorizado para su rol.");
        window.location.href = "index.html";
    }

    var pSesion = document.getElementById("infoSesion");
    if (pSesion) {
        pSesion.innerText = "Usuario: " + usuarioActual.nombres + " | Rol: " + usuarioActual.rol + " (Conectado)";
    }
}

// Botón de Cerrar Sesión
document.getElementById("btnCerrarSesion").addEventListener("click", function() {
    sessionStorage.removeItem("sesionActiva");
    window.location.href = "login.html";
});

// ==========================================
// DATOS DE PRODUCTO (Según entidad Producto de la BD)
// ==========================================
// Leer inventario de la memoria persistente para reflejar las recepciones sumadas (RF07 / RNF08)
var guardado = localStorage.getItem("inventario_sigaf");
var listaProductos = guardado ? JSON.parse(guardado) : [
    { codigo: "PROD-001", nombre: "Paracetamol 500mg", tipo: "Analgésico", unidad: "Caja x 100 tab", stock: 15, stockMinimo: 50 },
    { codigo: "PROD-002", nombre: "Amoxicilina 500mg", tipo: "Antibiótico", unidad: "Caja x 100 tab", stock: 8, stockMinimo: 40 },
    { codigo: "PROD-003", nombre: "Ibuprofeno 400mg", tipo: "Antiinflamatorio", unidad: "Blíster x 10", stock: 120, stockMinimo: 30 },
    { codigo: "PROD-004", nombre: "Omeprazol 20mg", tipo: "Antiácido", unidad: "Caja x 100 tab", stock: 5, stockMinimo: 25 },
    { codigo: "PROD-005", nombre: "Alcohol Medicinal 70°", tipo: "Antiséptico", unidad: "Frasco 120ml", stock: 65, stockMinimo: 20 }
];

var tablaInventario = document.getElementById("tablaInventario");
var txtBuscar = document.getElementById("buscarInsumo");

// Renderizar tabla de inventario
function renderizarTabla(productos) {
    tablaInventario.innerHTML = "";

    productos.forEach(function(item) {
        var fila = document.createElement("tr");

        // Determinar alerta de stock
        var requiereReposicion = item.stock <= item.stockMinimo;
        var estadoHtml = requiereReposicion 
            ? "<span style='color: #dc3545; font-weight: bold;'>Bajo stock (" + item.stock + ")</span>"
            : "<span style='color: #28a745; font-weight: bold;'>Normal (" + item.stock + ")</span>";

        fila.innerHTML = "<td><strong>" + item.codigo + "</strong></td>" +
                         "<td>" + item.nombre + "</td>" +
                         "<td>" + item.tipo + "</td>" +
                         "<td>" + item.unidad + "</td>" +
                         "<td>" + item.stock + "</td>" +
                         "<td>" + estadoHtml + "</td>" +
                         "<td><button onclick=\"solicitarReposicion('" + item.nombre + "', '" + item.unidad + "')\" style='background-color: #1a4f78; color: white; padding: 5px 10px; font-size: 12px; border: none; border-radius: 3px; cursor: pointer;'>Solicitar Reposición</button></td>";

        tablaInventario.appendChild(fila);
    });
}

// Búsqueda en tiempo real
txtBuscar.addEventListener("input", function() {
    var filtro = txtBuscar.value.toLowerCase();
    var filtrados = listaProductos.filter(function(prod) {
        return prod.nombre.toLowerCase().includes(filtro) || prod.codigo.toLowerCase().includes(filtro);
    });
    renderizarTabla(filtrados);
});

// Flujo alternativo/extensión a CU2: Enviar al formulario con los datos preseleccionados
window.solicitarReposicion = function(nombreProducto, unidadMedida) {
    sessionStorage.setItem("productoSeleccionado", JSON.stringify({
        producto: nombreProducto,
        unidad: unidadMedida
    }));
    window.location.href = "index.html";
};

// Carga inicial
renderizarTabla(listaProductos);