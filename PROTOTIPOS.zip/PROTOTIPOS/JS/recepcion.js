// ==========================================
// CONTROL DE ACCESO Y SEGURIDAD (RF10 / RNF01)
// ==========================================
var sesionGuardada = sessionStorage.getItem("sesionActiva");

if (!sesionGuardada) {
    alert("Acceso denegado: debe iniciar sesión primero.");
    window.location.href = "login.html";
} else {
    var usuarioActual = JSON.parse(sesionGuardada);

    if (usuarioActual.rol !== "Responsable de Recepción") {
        alert("Acceso no autorizado para su rol.");
        window.location.href = "login.html";
    }

    var pSesion = document.getElementById("infoSesion");
    if (pSesion) {
        pSesion.innerText = "Usuario: " + usuarioActual.nombres + " | Rol: " + usuarioActual.rol + " (Conectado)";
    }
}

// Botón de Cerrar Sesión
document.getElementById("btnCerrarSesion").addEventListener("click", function() {
    sessionStorage.removeItem("sesionActiva");
    window.location.href = "login.html";
});

// ==========================================
// PERSISTENCIA Y REGLAS DE NEGOCIO (RF05, RF06, RF07)
// ==========================================
var selectOrden = document.getElementById("selectOrdenCompra");
var infoProveedor = document.getElementById("infoProveedor");
var infoProducto = document.getElementById("infoProducto");
var infoCantidadPedida = document.getElementById("infoCantidadPedida");
var infoUnidad = document.getElementById("infoUnidad");

var txtRecibida = document.getElementById("txtCantRecibida");
var txtAceptada = document.getElementById("txtCantAceptada");
var txtRechazada = document.getElementById("txtCantRechazada");
var contenedorMotivo = document.getElementById("contenedorMotivoRechazo");
var txtMotivo = document.getElementById("txtMotivoRechazo");
var txtObs = document.getElementById("txtObsRecepcion");

var errOrden = document.getElementById("errorOrden");
var errRecibida = document.getElementById("errorRecibida");
var errAceptada = document.getElementById("errorAceptada");
var errMotivo = document.getElementById("errorMotivoRechazo");

var formulario = document.getElementById("formularioRecepcion");
var mensajeExito = document.getElementById("mensajeExitoRecepcion");
var tablaRecepciones = document.getElementById("tablaRecepcionesCuerpo");
var btnCancelar = document.getElementById("btnCancelarRecepcion");

// 1. Cargar Órdenes de Compra en estado "Emitida"
function cargarOrdenesPendientes() {
    var ordenes = JSON.parse(localStorage.getItem("ordenes_sigaf") || "[]");
    var emitidas = ordenes.filter(function(o) { return o.estado === "Emitida"; });

    selectOrden.innerHTML = "<option value=''>-- Seleccione una orden de compra --</option>";

    emitidas.forEach(function(o) {
        var opt = document.createElement("option");
        opt.value = o.codOrden;
        opt.innerText = o.codOrden + " - " + o.producto + " (" + o.cantidad + " " + o.unidad + ")";
        selectOrden.appendChild(opt);
    });

    if (emitidas.length === 0) {
        var optVacio = document.createElement("option");
        optVacio.disabled = true;
        optVacio.innerText = "(No hay órdenes de compra pendientes de recepción)";
        selectOrden.appendChild(optVacio);
    }
}

// Al seleccionar una orden, autocompletar datos esperados
selectOrden.addEventListener("change", function() {
    var ordenes = JSON.parse(localStorage.getItem("ordenes_sigaf") || "[]");
    var elegida = ordenes.find(function(o) { return o.codOrden === selectOrden.value; });

    if (elegida) {
        infoProveedor.value = elegida.proveedor;
        infoProducto.value = elegida.producto;
        infoCantidadPedida.value = elegida.cantidad;
        infoUnidad.value = elegida.unidad;
        
        // Sugerir la cantidad pedida por defecto
        txtRecibida.value = elegida.cantidad;
        txtAceptada.value = elegida.cantidad;
        calcularDiferencia();
    } else {
        infoProveedor.value = "";
        infoProducto.value = "";
        infoCantidadPedida.value = "";
        infoUnidad.value = "";
        txtRecibida.value = "";
        txtAceptada.value = "";
        txtRechazada.value = "0";
        contenedorMotivo.style.display = "none";
    }
});

// Cálculo automático de rechazo y activación de motivo (RF06)
function calcularDiferencia() {
    var rec = parseInt(txtRecibida.value, 10) || 0;
    var ace = parseInt(txtAceptada.value, 10) || 0;
    var rech = rec - ace;

    if (rech < 0) {
        rech = 0;
    }
    txtRechazada.value = rech;

    if (rech > 0) {
        contenedorMotivo.style.display = "block";
    } else {
        contenedorMotivo.style.display = "none";
        txtMotivo.value = "";
    }
}

txtRecibida.addEventListener("input", calcularDiferencia);
txtAceptada.addEventListener("input", calcularDiferencia);

// 2. Renderizar tabla de recepciones en historial
function cargarTablaRecepciones() {
    var recepciones = JSON.parse(localStorage.getItem("recepciones_sigaf") || "[]");
    tablaRecepciones.innerHTML = "";

    recepciones.forEach(function(r) {
        var fila = document.createElement("tr");
        fila.innerHTML = "<td><strong>" + r.codRecepcion + "</strong></td>" +
                         "<td>" + r.codOrden + "</td>" +
                         "<td>" + r.producto + "</td>" +
                         "<td><span style='color: #28a745; font-weight: bold;'>" + r.cantAceptada + "</span></td>" +
                         "<td><span style='color: " + (r.cantRechazada > 0 ? "#dc3545" : "#666") + "; font-weight: bold;'>" + r.cantRechazada + "</span></td>" +
                         "<td>" + r.usuarioReceptor + "</td>" +
                         "<td><span style='background-color: #d4edda; color: #155724; padding: 3px 8px; border-radius: 4px; font-size: 12px; font-weight: bold;'>" + r.estado + "</span></td>";
        tablaRecepciones.appendChild(fila);
    });
}

// 3. Confirmar recepción y actualizar inventario (Diagramas 1.6 y 1.7)
formulario.addEventListener("submit", function(evento) {
    evento.preventDefault();
    limpiarErrores();
    mensajeExito.style.display = "none";

    var valido = true;
    var rec = parseInt(txtRecibida.value, 10);
    var ace = parseInt(txtAceptada.value, 10);
    var rech = parseInt(txtRechazada.value, 10);

    if (!selectOrden.value) {
        selectOrden.className = "borde-rojo";
        errOrden.innerText = "Debe seleccionar una orden de compra.";
        valido = false;
    }

    if (isNaN(rec) || rec <= 0) {
        txtRecibida.className = "borde-rojo";
        errRecibida.innerText = "La cantidad recibida debe ser mayor a cero.";
        valido = false;
    }

    if (isNaN(ace) || ace < 0 || ace > rec) {
        txtAceptada.className = "borde-rojo";
        errAceptada.innerText = "La cantidad aceptada no puede ser menor a 0 ni superar la cantidad recibida.";
        valido = false;
    }

    if (rech > 0 && txtMotivo.value.trim() === "") {
        txtMotivo.className = "borde-rojo";
        errMotivo.innerText = "Debe indicar el motivo de rechazo de las unidades no conformes (RF06).";
        valido = false;
    }

    if (!valido) return;

    // Generar correlativo REC-2026-001...
    var recepciones = JSON.parse(localStorage.getItem("recepciones_sigaf") || "[]");
    var nuevoCodRecepcion = "REC-2026-" + String(recepciones.length + 1).padStart(3, "0");

    var nuevaRecepcion = {
        codRecepcion: nuevoCodRecepcion,
        codOrden: selectOrden.value,
        producto: infoProducto.value,
        cantRecibida: rec,
        cantAceptada: ace,
        cantRechazada: rech,
        motivoRechazo: txtMotivo.value.trim(),
        observaciones: txtObs.value.trim(),
        usuarioReceptor: JSON.parse(sesionGuardada).nombres,
        fechaRecepcion: new Date().toLocaleDateString(),
        estado: "Conforme y Procesada"
    };

    recepciones.push(nuevaRecepcion);
    localStorage.setItem("recepciones_sigaf", JSON.stringify(recepciones));

    // Cambiar estado de la orden de compra a "Recibida"
    var ordenes = JSON.parse(localStorage.getItem("ordenes_sigaf") || "[]");
    var ordIdx = ordenes.findIndex(function(o) { return o.codOrden === selectOrden.value; });
    if (ordIdx !== -1) {
        ordenes[ordIdx].estado = "Recibida";
        localStorage.setItem("ordenes_sigaf", JSON.stringify(ordenes));
    }

    // ========================================================
    // ACTUALIZAR INVENTARIO (RF07 / Diagrama de Secuencia 1.7)
    // Suma únicamente las cantidades aceptadas al stock del producto
    // ========================================================
    actualizarStockInventario(infoProducto.value, ace);

    // Mensaje de éxito
    mensajeExito.innerHTML = "Recepción <strong>" + nuevoCodRecepcion + "</strong> registrada exitosamente. Se sumaron <strong>" + ace + "</strong> unidades de <strong>" + infoProducto.value + "</strong> al stock del inventario.";
    mensajeExito.style.display = "block";

    formulario.reset();
    infoProveedor.value = "";
    infoProducto.value = "";
    infoCantidadPedida.value = "";
    infoUnidad.value = "";
    txtRechazada.value = "0";
    contenedorMotivo.style.display = "none";

    cargarOrdenesPendientes();
    cargarTablaRecepciones();
});

// Función que impacta en el inventario real (RF07)
function actualizarStockInventario(nombreProd, cantidadSumar) {
    var productosGuardados = JSON.parse(localStorage.getItem("inventario_sigaf") || "null");

    var lista = productosGuardados || [
        { codigo: "PROD-001", nombre: "Paracetamol 500mg", tipo: "Analgésico", unidad: "Caja x 100 tab", stock: 15, stockMinimo: 50 },
        { codigo: "PROD-002", nombre: "Amoxicilina 500mg", tipo: "Antibiótico", unidad: "Caja x 100 tab", stock: 8, stockMinimo: 40 },
        { codigo: "PROD-003", nombre: "Ibuprofeno 400mg", tipo: "Antiinflamatorio", unidad: "Blíster x 10", stock: 120, stockMinimo: 30 },
        { codigo: "PROD-004", nombre: "Omeprazol 20mg", tipo: "Antiácido", unidad: "Caja x 100 tab", stock: 5, stockMinimo: 25 },
        { codigo: "PROD-005", nombre: "Alcohol Medicinal 70°", tipo: "Antiséptico", unidad: "Frasco 120ml", stock: 65, stockMinimo: 20 }
    ];

    var item = lista.find(function(p) {
        return nombreProd.toLowerCase().includes(p.nombre.toLowerCase().split(" ")[0]);
    });

    if (item) {
        item.stock = parseInt(item.stock, 10) + cantidadSumar;
        localStorage.setItem("inventario_sigaf", JSON.stringify(lista));
    }
}

btnCancelar.addEventListener("click", function() {
    formulario.reset();
    infoProveedor.value = "";
    infoProducto.value = "";
    infoCantidadPedida.value = "";
    infoUnidad.value = "";
    txtRechazada.value = "0";
    contenedorMotivo.style.display = "none";
    limpiarErrores();
    mensajeExito.style.display = "none";
});

function limpiarErrores() {
    selectOrden.className = "";
    txtRecibida.className = "";
    txtAceptada.className = "";
    txtMotivo.className = "";
    errOrden.innerText = "";
    errRecibida.innerText = "";
    errAceptada.innerText = "";
    errMotivo.innerText = "";
}

// Carga inicial
cargarOrdenesPendientes();
cargarTablaRecepciones();