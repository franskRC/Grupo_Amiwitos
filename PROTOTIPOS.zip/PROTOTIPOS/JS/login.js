// Simulación de la entidad "Usuario" de la base de datos (según diagrama de clases)
var usuariosRegistrados = [
    {
        nombreUsuario: "operador1",
        contrasena: "1234",
        nombres: "Carlos Mendoza",
        rol: "Operador de Almacén"
    },
    {
        nombreUsuario: "abastecedor1",
        contrasena: "1234",
        nombres: "Dra. Sofía Valdivia",
        rol: "Responsable de Abastecimiento"
    },
    {
        nombreUsuario: "receptor1",
        contrasena: "1234",
        nombres: "Miguel Ramos",
        rol: "Responsable de Recepción"
    }
];

var formularioLogin = document.getElementById("formularioLogin");
var txtUsuario = document.getElementById("nombreUsuario");
var txtContrasena = document.getElementById("contrasena");
var selectRol = document.getElementById("rolUsuario");

var errUsuario = document.getElementById("errorUsuario");
var errContrasena = document.getElementById("errorContrasena");
var errRol = document.getElementById("errorRol");
var alertaError = document.getElementById("alertaError");

formularioLogin.addEventListener("submit", function(evento) {
    evento.preventDefault();

    // Limpiar alertas previas
    limpiarValidaciones();
    alertaError.style.display = "none";

    var formularioValido = true;

    if (txtUsuario.value.trim() === "") {
        txtUsuario.className = "borde-rojo";
        errUsuario.innerText = "Ingrese su nombre de usuario.";
        formularioValido = false;
    }

    if (txtContrasena.value.trim() === "") {
        txtContrasena.className = "borde-rojo";
        errContrasena.innerText = "Ingrese su contraseña.";
        formularioValido = false;
    }

    if (selectRol.value === "") {
        selectRol.className = "borde-rojo";
        errRol.innerText = "Seleccione el rol correspondiente.";
        formularioValido = false;
    }

    if (!formularioValido) {
        return;
    }

    // Validación de credenciales con la lista de usuarios
    var usuarioEncontrado = usuariosRegistrados.find(function(user) {
        return user.nombreUsuario === txtUsuario.value.trim() &&
               user.contrasena === txtContrasena.value.trim() &&
               user.rol === selectRol.value;
    });

    if (usuarioEncontrado) {
        // Guardar sesión activa (cumple precondición de sesión iniciada para CU1-CU5)
        var sesion = {
            nombres: usuarioEncontrado.nombres,
            nombreUsuario: usuarioEncontrado.nombreUsuario,
            rol: usuarioEncontrado.rol,
            fechaIngreso: new Date().toLocaleTimeString()
        };
        sessionStorage.setItem("sesionActiva", JSON.stringify(sesion));

        // Redirigir a la pantalla principal del sistema
        // Redirigir a la pantalla correspondiente según el rol (RF10)
        if (usuarioEncontrado.rol === "Operador de Almacén") {
            window.location.href = "index.html";
        } else if (usuarioEncontrado.rol === "Responsable de Abastecimiento") {
            window.location.href = "evaluar-solicitud.html";
        } else if (usuarioEncontrado.rol === "Responsable de Recepción") {
            window.location.href = "recepcion.html";
        }
    } else {
        alertaError.innerText = "Credenciales incorrectas o el rol seleccionado no coincide con el usuario.";
        alertaError.style.display = "block";
    }
});

function limpiarValidaciones() {
    txtUsuario.className = "";
    txtContrasena.className = "";
    selectRol.className = "";
    errUsuario.innerText = "";
    errContrasena.innerText = "";
    errRol.innerText = "";
}