// ==========================================
// CONTROL DE ACCESO Y SEGURIDAD (RF10 / RNF01)
// ==========================================
var sesionGuardada = sessionStorage.getItem("sesionActiva");

if (!sesionGuardada) {
    alert("Acceso denegado: debe iniciar sesión primero.");
    window.location.href = "login.html";
} else {
    var usuarioActual = JSON.parse(sesionGuardada);

    if (usuarioActual.rol !== "Responsable de Abastecimiento") {
        alert("Acceso no autorizado para su rol.");
        window.location.href = "login.html";
    }

    var pSesion = document.getElementById("infoSesion");
    if (pSesion) {
        pSesion.innerText = "Usuario: " + usuarioActual.nombres + " | Rol: " + usuarioActual.rol + " (Conectado)";
    }
}

// Botón Cerrar Sesión
document.getElementById("btnCerrarSesion").addEventListener("click", function() {
    sessionStorage.removeItem("sesionActiva");
    window.location.href = "login.html";
});

// ==========================================
// PERSISTENCIA Y REGLAS DE NEGOCIO (CU5 / RF04)
// ==========================================
var selectSolicitud = document.getElementById("selectSolicitudAutorizada");
var infoProducto = document.getElementById("infoProducto");
var infoCantidad = document.getElementById("infoCantidad");
var infoUnidad = document.getElementById("infoUnidad");
var selectProveedor = document.getElementById("selectProveedor");
var txtObs = document.getElementById("txtObservacionesCompra");

var errSolicitud = document.getElementById("errorSolicitud");
var errProveedor = document.getElementById("errorProveedor");
var formulario = document.getElementById("formularioOrdenCompra");
var mensajeExito = document.getElementById("mensajeExitoOrden");
var tablaOrdenes = document.getElementById("tablaOrdenesCuerpo");
var btnCancelar = document.getElementById("btnCancelarOrden");

// 1. Obtener solicitudes y filtrar solo las AUTORIZADAS (RF04)
function cargarSolicitudesAutorizadas() {
    var solicitudes = JSON.parse(localStorage.getItem("solicitudes_sigaf") || "[]");
    var ordenesExistentes = JSON.parse(localStorage.getItem("ordenes_sigaf") || "[]");

    // Filtrar solicitudes autorizadas que aún no tengan orden emitida
    var autorizadasSinOrden = solicitudes.filter(function(s) {
        var yaTieneOrden = ordenesExistentes.some(function(o) { return o.codSolicitud === s.codigo; });
        return s.estado === "Autorizada" && !yaTieneOrden;
    });

    selectSolicitud.innerHTML = "<option value=''>-- Seleccione una solicitud autorizada --</option>";

    autorizadasSinOrden.forEach(function(s) {
        var opt = document.createElement("option");
        opt.value = s.codigo;
        opt.innerText = s.codigo + " - " + s.producto + " (" + s.cantidad + " " + s.unidad + ")";
        selectSolicitud.appendChild(opt);
    });

    if (autorizadasSinOrden.length === 0) {
        var optVacio = document.createElement("option");
        optVacio.disabled = true;
        optVacio.innerText = "(No hay solicitudes autorizadas pendientes de orden)";
        selectSolicitud.appendChild(optVacio);
    }
}

// Al seleccionar una solicitud, autocompletar los datos de solo lectura
selectSolicitud.addEventListener("change", function() {
    var solicitudes = JSON.parse(localStorage.getItem("solicitudes_sigaf") || "[]");
    var elegida = solicitudes.find(function(s) { return s.codigo === selectSolicitud.value; });

    if (elegida) {
        infoProducto.value = elegida.producto;
        infoCantidad.value = elegida.cantidad;
        infoUnidad.value = elegida.unidad;
    } else {
        infoProducto.value = "";
        infoCantidad.value = "";
        infoUnidad.value = "";
    }
});

// 2. Renderizar tabla de órdenes emitidas
function cargarTablaOrdenes() {
    var ordenes = JSON.parse(localStorage.getItem("ordenes_sigaf") || "[]");
    tablaOrdenes.innerHTML = "";

    ordenes.forEach(function(o) {
        var fila = document.createElement("tr");
        fila.innerHTML = "<td><strong>" + o.codOrden + "</strong></td>" +
                         "<td>" + o.codSolicitud + "</td>" +
                         "<td>" + o.producto + "</td>" +
                         "<td>" + o.cantidad + " " + o.unidad + "</td>" +
                         "<td>" + o.proveedor + "</td>" +
                         "<td><span style='background-color: #cce5ff; color: #004085; padding: 3px 8px; border-radius: 4px; font-size: 12px; font-weight: bold;'>" + o.estado + "</span></td>";
        tablaOrdenes.appendChild(fila);
    });
}

// 3. Emitir la Orden de Compra (CU5 Paso 6 a 10)
formulario.addEventListener("submit", function(evento) {
    evento.preventDefault();
    limpiarErrores();
    mensajeExito.style.display = "none";

    var valido = true;

    if (!selectSolicitud.value) {
        selectSolicitud.className = "borde-rojo";
        errSolicitud.innerText = "Debe seleccionar una solicitud autorizada.";
        valido = false;
    }

    if (!selectProveedor.value) {
        selectProveedor.className = "borde-rojo";
        errProveedor.innerText = "Debe asignar un proveedor para la orden.";
        valido = false;
    }

    if (!valido) return;

    // Generar correlativo OC-2026-001, OC-2026-002...
    var ordenes = JSON.parse(localStorage.getItem("ordenes_sigaf") || "[]");
    var numeroOrden = ordenes.length + 1;
    var nuevoCodOrden = "OC-2026-" + String(numeroOrden).padStart(3, "0");

    var nuevaOrden = {
        codOrden: nuevoCodOrden,
        codSolicitud: selectSolicitud.value,
        producto: infoProducto.value,
        cantidad: infoCantidad.value,
        unidad: infoUnidad.value,
        proveedor: selectProveedor.value,
        observaciones: txtObs.value.trim(),
        emisor: JSON.parse(sesionGuardada).nombres,
        fechaEmision: new Date().toLocaleDateString(),
        estado: "Emitida" // Queda lista para CU6: Recepción de pedido
    };

    ordenes.push(nuevaOrden);
    localStorage.setItem("ordenes_sigaf", JSON.stringify(ordenes));

    // Confirmación en pantalla
    mensajeExito.innerHTML = "Orden de Compra <strong>" + nuevoCodOrden + "</strong> emitida exitosamente y vinculada a <strong>" + selectSolicitud.value + "</strong>. Disponible para recepción.";
    mensajeExito.style.display = "block";

    formulario.reset();
    infoProducto.value = "";
    infoCantidad.value = "";
    infoUnidad.value = "";

    cargarSolicitudesAutorizadas();
    cargarTablaOrdenes();
});

btnCancelar.addEventListener("click", function() {
    formulario.reset();
    infoProducto.value = "";
    infoCantidad.value = "";
    infoUnidad.value = "";
    limpiarErrores();
    mensajeExito.style.display = "none";
});

function limpiarErrores() {
    selectSolicitud.className = "";
    selectProveedor.className = "";
    errSolicitud.innerText = "";
    errProveedor.innerText = "";
}

// Carga inicial
cargarSolicitudesAutorizadas();
cargarTablaOrdenes();