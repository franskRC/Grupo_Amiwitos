// ==========================================
// CONTROL DE ACCESO Y SEGURIDAD (RF10 / RNF01)
// ==========================================
var sesionGuardada = sessionStorage.getItem("sesionActiva");

if (!sesionGuardada) {
    alert("Acceso denegado: debe iniciar sesión primero.");
    window.location.href = "login.html";
} else {
    var usuarioActual = JSON.parse(sesionGuardada);

    // Validar que solo el Responsable de Abastecimiento acceda a esta pantalla
    if (usuarioActual.rol !== "Responsable de Abastecimiento") {
        alert("Acceso denegado: esta pantalla corresponde únicamente al Responsable de Abastecimiento.");
        window.location.href = "index.html";
    }

    var pSesion = document.getElementById("infoSesion");
    if (pSesion) {
        pSesion.innerText = "Usuario: " + usuarioActual.nombres + " | Rol: " + usuarioActual.rol + " (Conectado)";
    }
}

// Cerrar sesión
document.getElementById("btnCerrarSesion").addEventListener("click", function() {
    sessionStorage.removeItem("sesionActiva");
    window.location.href = "login.html";
});

function obtenerSolicitudes() {
    var guardadas = localStorage.getItem("solicitudes_sigaf");
    if (!guardadas) {
        var baseInicial = [
            {
                codigo: "SOL-2026-001",
                producto: "Amoxicilina 500mg",
                cantidad: "200",
                unidad: "Caja x 100 tab",
                justificacion: "Stock por debajo del mínimo en farmacia central",
                estado: "Pendiente de evaluación",
                motivo: ""
            }
        ];
        localStorage.setItem("solicitudes_sigaf", JSON.stringify(baseInicial));
        return baseInicial;
    }
    return JSON.parse(guardadas);
}


function guardarSolicitudes(lista) {
    localStorage.setItem("solicitudes_sigaf", JSON.stringify(lista));
}

// Elementos del DOM
var tablaPendientes = document.getElementById("tablaPendientes");
var sinPendientes = document.getElementById("sinPendientes");
var panelEvaluacion = document.getElementById("panelEvaluacion");

var lblCodigo = document.getElementById("lblCodigoSolicitud");
var detProducto = document.getElementById("detProducto");
var detCantidad = document.getElementById("detCantidad");
var detUnidad = document.getElementById("detUnidad");
var detJustificacion = document.getElementById("detJustificacion");

var decisionSelect = document.getElementById("decisionEvaluador");
var contenedorMotivo = document.getElementById("contenedorMotivo");
var lblMotivo = document.getElementById("lblMotivo");
var txtMotivo = document.getElementById("txtMotivoEvaluacion");

var errDecision = document.getElementById("errorDecision");
var errMotivo = document.getElementById("errorMotivo");
var formEvaluacion = document.getElementById("formularioEvaluacion");
var mensajeResultado = document.getElementById("mensajeResultado");
var btnCancelar = document.getElementById("btnCancelarEvaluacion");

var solicitudSeleccionada = null;

// CU3: Renderizar solicitudes que se encuentran en estado 'Pendiente de evaluación'
function cargarBandejaPendientes() {
    var solicitudes = obtenerSolicitudes();
    var pendientes = solicitudes.filter(function(s) {
        return s.estado === "Pendiente de evaluación";
    });

    tablaPendientes.innerHTML = "";

    if (pendientes.length === 0) {
        sinPendientes.style.display = "block";
        panelEvaluacion.style.display = "none";
        return;
    }

    sinPendientes.style.display = "none";

    pendientes.forEach(function(sol) {
        var fila = document.createElement("tr");
        fila.innerHTML = "<td><strong>" + sol.codigo + "</strong></td>" +
                         "<td>" + sol.producto + "</td>" +
                         "<td>" + sol.cantidad + "</td>" +
                         "<td>" + sol.unidad + "</td>" +
                         "<td><span class='badge-pendiente'>" + sol.estado + "</span></td>" +
                         "<td><button onclick=\"seleccionarParaEvaluar('" + sol.codigo + "')\" style='background-color: #1a4f78; color: white; padding: 5px 12px; font-size: 12px; border: none; border-radius: 4px; cursor: pointer;'>Ver Detalle</button></td>";
        tablaPendientes.appendChild(fila);
    });
}

// CU3 Paso 5: Mostrar el detalle de la solicitud seleccionada
window.seleccionarParaEvaluar = function(codigo) {
    var solicitudes = obtenerSolicitudes();
    solicitudSeleccionada = solicitudes.find(function(s) { return s.codigo === codigo; });

    if (solicitudSeleccionada) {
        lblCodigo.innerText = solicitudSeleccionada.codigo;
        detProducto.value = solicitudSeleccionada.producto;
        detCantidad.value = solicitudSeleccionada.cantidad;
        detUnidad.value = solicitudSeleccionada.unidad;
        detJustificacion.value = solicitudSeleccionada.justificacion;

        // Resetear campos de evaluación
        decisionSelect.value = "";
        txtMotivo.value = "";
        contenedorMotivo.style.display = "none";
        limpiarErrores();
        mensajeResultado.style.display = "none";

        panelEvaluacion.style.display = "block";
        panelEvaluacion.scrollIntoView({ behavior: "smooth" });
    }
};

// CU4: Si elige 'Rechazar' o 'Devolver para corrección', el motivo es obligatorio
decisionSelect.addEventListener("change", function() {
    limpiarErrores();
    var valor = decisionSelect.value;

    if (valor === "Rechazada") {
        contenedorMotivo.style.display = "block";
        lblMotivo.innerText = "Motivo del Rechazo:";
        txtMotivo.placeholder = "Indique claramente la razón por la que se rechaza la solicitud...";
    } else if (valor === "Devuelta para corrección") {
        contenedorMotivo.style.display = "block";
        lblMotivo.innerText = "Observaciones para la Corrección:";
        txtMotivo.placeholder = "Indique al operador qué datos o campos debe subsanar...";
    } else {
        // Si es Autorizada, no es estrictamente obligatorio el motivo
        contenedorMotivo.style.display = "none";
    }
});

// CU4: Procesar Decisión
formEvaluacion.addEventListener("submit", function(evento) {
    evento.preventDefault();
    limpiarErrores();
    mensajeResultado.style.display = "none";

    var esValido = true;
    var decision = decisionSelect.value;

    if (!decision) {
        decisionSelect.className = "borde-rojo";
        errDecision.innerText = "Debe elegir una decisión para la solicitud.";
        esValido = false;
    }

    // Regla Alternativa A2 y A3 del CU4: Motivo/observación no puede ser vacío
    if ((decision === "Rechazada" || decision === "Devuelta para corrección") && txtMotivo.value.trim() === "") {
        txtMotivo.className = "borde-rojo";
        errMotivo.innerText = (decision === "Rechazada") 
            ? "El motivo de rechazo es obligatorio."
            : "Las observaciones para la corrección son obligatorias.";
        esValido = false;
    }

    if (!esValido) return;

    // Actualizar el estado en la base persistente
    var solicitudes = obtenerSolicitudes();
    var indice = solicitudes.findIndex(function(s) { return s.codigo === solicitudSeleccionada.codigo; });

    if (indice !== -1) {
        solicitudes[indice].estado = decision;
        solicitudes[indice].motivo = txtMotivo.value.trim();
        solicitudes[indice].evaluador = JSON.parse(sesionGuardada).nombres;
        solicitudes[indice].fechaEvaluacion = new Date().toLocaleString();

        guardarSolicitudes(solicitudes);

        // Mostrar confirmación
        mensajeResultado.innerHTML = "Decisión guardada con éxito. La solicitud <strong>" + solicitudSeleccionada.codigo + "</strong> pasó a estado: <strong>" + decision + "</strong>.";
        mensajeResultado.style.display = "block";

        // Refrescar bandeja tras 1.5 segundos
        setTimeout(function() {
            panelEvaluacion.style.display = "none";
            cargarBandejaPendientes();
        }, 1500);
    }
});

btnCancelar.addEventListener("click", function() {
    panelEvaluacion.style.display = "none";
});

function limpiarErrores() {
    decisionSelect.className = "";
    txtMotivo.className = "";
    errDecision.innerText = "";
    errMotivo.innerText = "";
}

// Carga inicial
cargarBandejaPendientes();