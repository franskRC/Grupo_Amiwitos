// ==========================================
// CONTROL DE ACCESO Y SEGURIDAD (RF10 / RNF01)
// ==========================================
var sesionGuardada = sessionStorage.getItem("sesionActiva");

// Si no hay sesión iniciada, devuelve al login (cumple la precondición de CU2)
if (!sesionGuardada) {
    alert("Acceso denegado: debe iniciar sesión primero.");
    window.location.href = "login.html";
} else {
    var usuarioActual = JSON.parse(sesionGuardada);

    // Mostrar nombre y rol en la cabecera
    var pSesion = document.getElementById("infoSesion");
    if (pSesion) {
        pSesion.innerText = "Usuario: " + usuarioActual.nombres + " | Rol: " + usuarioActual.rol + " (Conectado)";
    }

    // Filtrar opciones del menú según el rol autenticado (RF10)
    var menusOperador = document.querySelectorAll(".menu-operador");
    var menusAbastecimiento = document.querySelectorAll(".menu-abastecimiento");
    var menusRecepcion = document.querySelectorAll(".menu-recepcion");

    // Ocultar todos por defecto
    menusOperador.forEach(function(el) { el.style.display = "none"; });
    menusAbastecimiento.forEach(function(el) { el.style.display = "none"; });
    menusRecepcion.forEach(function(el) { el.style.display = "none"; });

    // Habilitar según el perfil activo
    if (usuarioActual.rol === "Operador de Almacén") {
        menusOperador.forEach(function(el) { el.style.display = "inline-block"; });
    } else if (usuarioActual.rol === "Responsable de Abastecimiento") {
        menusAbastecimiento.forEach(function(el) { el.style.display = "inline-block"; });
    } else if (usuarioActual.rol === "Responsable de Recepción") {
        menusRecepcion.forEach(function(el) { el.style.display = "inline-block"; });
    }
}

// Botón de Cerrar Sesión
var btnCerrar = document.getElementById("btnCerrarSesion");
if (btnCerrar) {
    btnCerrar.addEventListener("click", function() {
        sessionStorage.removeItem("sesionActiva");
        window.location.href = "login.html";
    });
}
// ==========================================

// Referencias a los elementos del formulario
var formulario = document.getElementById("formularioSolicitud");
var txtProducto = document.getElementById("producto");
var txtCantidad = document.getElementById("cantidad");
var selectUnidad = document.getElementById("unidadMedida");
var txtJustificacion = document.getElementById("justificacion");

// Referencias a los textos de error
var errProducto = document.getElementById("errorProducto");
var errCantidad = document.getElementById("errorCantidad");
var errUnidad = document.getElementById("errorUnidad");
var errJustificacion = document.getElementById("errorJustificacion");

// Mensaje y tabla
var mensajeExito = document.getElementById("mensajeExito");
var tablaCuerpo = document.getElementById("tablaCuerpo");
var btnCancelar = document.getElementById("btnCancelar");

// Contador para simular la generación correlativa del código de solicitud
var correlativo = 2;

// Precargar producto si viene de la pantalla de inventario (CU1 -> CU2)
var prodPrecargado = sessionStorage.getItem("productoSeleccionado");
if (prodPrecargado) {
    var data = JSON.parse(prodPrecargado);
    txtProducto.value = data.producto;
    selectUnidad.value = data.unidad;
    sessionStorage.removeItem("productoSeleccionado"); // Se limpia después de cargarlo
}

// Evento al presionar el botón "Registrar"
formulario.addEventListener("submit", function(evento) {
    evento.preventDefault();

    limpiarErrores();
    mensajeExito.style.display = "none";

    var esValido = true;

    // 1. Validar producto obligatorio
    if (txtProducto.value.trim() === "") {
        txtProducto.className = "borde-rojo";
        errProducto.innerText = "Debe ingresar el producto o insumo.";
        esValido = false;
    }

    // 2. Validar cantidad mayor a cero (Regla RF01 y CU2)
    var cant = parseInt(txtCantidad.value, 10);
    if (txtCantidad.value.trim() === "" || isNaN(cant) || cant <= 0) {
        txtCantidad.className = "borde-rojo";
        errCantidad.innerText = "La cantidad debe ser obligatoria y mayor que cero.";
        esValido = false;
    }

    // 3. Validar unidad de medida
    if (selectUnidad.value === "") {
        selectUnidad.className = "borde-rojo";
        errUnidad.innerText = "Seleccione una unidad de medida.";
        esValido = false;
    }

    // 4. Validar justificación obligatoria
    if (txtJustificacion.value.trim() === "") {
        txtJustificacion.className = "borde-rojo";
        errJustificacion.innerText = "Debe ingresar la justificación de la solicitud.";
        esValido = false;
    }

    // Si todo es conforme (Flujo Básico - Datos Válidos)
    // Si todo es conforme (Flujo Básico - Datos Válidos)
    // Si los datos son conformes (Flujo Básico del CU2 / RF01)
    if (esValido) {
        // 1. Leemos lo que ya está guardado en el navegador
        var listaActual = JSON.parse(localStorage.getItem("solicitudes_sigaf") || "[]");

        // 2. Generamos el código correlativo único (SOL-2026-001, SOL-2026-002...)
        var numeroNuevo = listaActual.length + 1;
        var codGenerado = "SOL-2026-" + String(numeroNuevo).padStart(3, "0");

        // 3. Creamos el objeto con los datos ingresados
        var nuevaSolicitud = {
            codigo: codGenerado,
            producto: txtProducto.value.trim(),
            cantidad: txtCantidad.value.trim(),
            unidad: selectUnidad.value,
            justificacion: txtJustificacion.value.trim(),
            estado: "Pendiente de evaluación",
            motivo: ""
        };

        // 4. Guardamos en la memoria persistente (RNF08)
        listaActual.push(nuevaSolicitud);
        localStorage.setItem("solicitudes_sigaf", JSON.stringify(listaActual));

        cargarTablaSolicitudes(); 
        // Esta función lee la memoria recién actualizada y redibuja la tabla completa automáticamente

        // 5. Mensaje de confirmación al usuario
        mensajeExito.innerHTML = "Solicitud <strong>" + codGenerado + "</strong> registrada correctamente con estado <em>Pendiente de evaluación</em>.";
        mensajeExito.style.display = "block";

        // 6. Limpiamos las cajas de texto del formulario
        formulario.reset();
    }
});

// Botón Cancelar: limpia el formulario y errores
btnCancelar.addEventListener("click", function() {
    formulario.reset();
    limpiarErrores();
    mensajeExito.style.display = "none";
});

function limpiarErrores() {
    txtProducto.className = "";
    txtCantidad.className = "";
    selectUnidad.className = "";
    txtJustificacion.className = "";

    errProducto.innerText = "";
    errCantidad.innerText = "";
    errUnidad.innerText = "";
    errJustificacion.innerText = "";
}

// Función para pintar en la tabla todas las solicitudes guardadas en persistencia (RF02 / RNF08)
function cargarTablaSolicitudes() {
    var solicitudes = JSON.parse(localStorage.getItem("solicitudes_sigaf") || "[]");
    
    // Si la memoria está vacía, creamos la primera por defecto
    if (solicitudes.length === 0) {
        solicitudes = [
            {
                codigo: "SOL-2026-001",
                producto: "Amoxicilina 500mg",
                cantidad: "200",
                unidad: "Caja x 100 tab",
                justificacion: "Stock por debajo del mínimo",
                estado: "Pendiente de evaluación"
            }
        ];
        localStorage.setItem("solicitudes_sigaf", JSON.stringify(solicitudes));
    }

    // Limpiamos el cuerpo de la tabla para rellenarlo con la memoria actualizada
    tablaCuerpo.innerHTML = "";

    solicitudes.forEach(function(sol) {
        var fila = document.createElement("tr");
        
        // Estilo según el estado de la solicitud
        var badgeColor = "badge-pendiente";
        if (sol.estado === "Autorizada") badgeColor = "badge-autorizada";
        if (sol.estado === "Rechazada") badgeColor = "badge-rechazada";

        fila.innerHTML = "<td><strong>" + sol.codigo + "</strong></td>" +
                         "<td>" + sol.producto + "</td>" +
                         "<td>" + sol.cantidad + "</td>" +
                         "<td>" + sol.unidad + "</td>" +
                         "<td>" + sol.justificacion + "</td>" +
                         "<td><span class='" + badgeColor + "'>" + sol.estado + "</span></td>";

        tablaCuerpo.appendChild(fila);
    });
}

// Cargar la tabla automáticamente al entrar a la pantalla
cargarTablaSolicitudes();